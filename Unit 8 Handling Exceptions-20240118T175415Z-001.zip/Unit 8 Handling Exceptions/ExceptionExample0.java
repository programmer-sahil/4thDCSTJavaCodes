// Java Program to Demonstrate How Exception Is Thrown
class ExceptionExample0 {

	// Main driver method
	public static void main(String args[]) {
		// Taking an empty string
		String str = null;
		// Getting length of a string
		System.out.println(str.length());
	}
}
